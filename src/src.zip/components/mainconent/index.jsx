import React, { Component } from 'react'
import { Modal, ModalBody, ModalHeader } from 'reactstrap'
import ParticipationFrom from './participation-form'
import PollForm from '../pollform'

export default class Maincontent extends Component {
  state = {
    openModal: false
  }
  toggleModal = () => {
    this.setState({
      openModal: !this.state.openModal
    })
  }
  
  render() {
    if( Object.keys(this.props.poll).length ===0){
      return (
        <h2>You can make anythng here</h2>
      )
    }
    const {poll,getOpinion, updatePoll,deletePoll,opiShow} = this.props;
    return (
      <div>
        <h3>{poll.title}</h3>
        <p>{poll.description}</p>
        <br></br>
          <ParticipationFrom
            poll={poll}
            getOpinion={getOpinion}
            toggleModal={this.toggleModal}
            deletePoll={deletePoll}
            opiShow = {opiShow}
          />

          <Modal isOpen={this.state.openModal} toggle={this.toggleModal} unmountOnClose={true}>
            <ModalHeader toggle={this.toggleModal}>
                UPdate Modal
            </ModalHeader>
            <ModalBody>
                  <PollForm 
                    poll={poll}
                    isUpdate={true}  // yes it is updating
                    submit={updatePoll}
                    buttonValue='update POll'
                    
                  />
            </ModalBody>

          </Modal>
      </div>
    )
  }
}
