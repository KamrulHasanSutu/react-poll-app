import React, { Component } from 'react'
import shortid from 'shortid'
import MyForm from './form'

const defaultOptions = [
    { id: shortid.generate(), value: '', vote: 0 },
    { id: shortid.generate(), value: '', vote: 0 }
]
export default class PollForm extends Component {
    state = {
        title: '',
        description: '',
        options: defaultOptions,
        errors: {}
    }
    // click edit >
    componentDidMount() {
        const { poll } = this.props
        if (poll && Object.keys(poll).length > 0) {
            this.setState({
                title: poll.title,
                description: poll.description,
                options: poll.options
            })
        }
    }

    handleChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    handleOptionChange = (e, index) => {
        const options = [...this.state.options];
        options[index].value = e.target.value;
        this.setState({ options })
    }
    createOption = () => {
        const options = [...this.state.options];

        if (options.length < 5) {
            options.push({
                id: shortid.generate(),
                value: '',
                vote: ''
            })
            this.setState({ options })
        } else {
            alert("more than 5 options cannot be done")
        }
    }
    deleteOption = index => {
        const options = [...this.state.options]
        if (options.length > 2) {
            options.splice(index, 1);
            this.setState({ options })
        } else {
            alert("2 option must be at")
        }

    }
    handleSubmit = e => {
        e.preventDefault();
        const { errors, isValid } = this.validate()

        if (isValid) {
            const { title, description, options } = this.state;
            const poll = {
                title,
                description, options
            }

            if (this.props.isUpdate) {
                poll.id = this.props.poll.id
                this.props.submit(poll)
                alert("UPdated successsfully")
            }

            else {
                this.props.submit(poll)
                e.target.reset();
                this.setState({
                    title: '',
                    description: '',
                    options: defaultOptions,
                    errors: {}
                })
            }
        }
        else {
            this.setState({ errors })
        }
    }
    validate = () => {
        const errors = {};
        const { title, description, options } = this.state;
        // title
        if (!title) { errors.title = "plz provide a title" }
        else if (title.length < 5) {
            errors.title = "title too short";
        }
        else if (title.length > 100) {
            errors.title = "title too long";
        }
        // description
        if (!description) { errors.description = "plz provide a description" }
        else if (description.length < 5) {
            errors.description = "description too short";
        }
        else if (description.length > 300) {
            errors.description = "description too long";
        }

        const optionErrors = [];
        options.forEach((opt, index) => {
            if (!opt.value) {
                optionErrors[index] = "option text empty"
            } else if (!opt.value.length > 20) {
                optionErrors[index] = 'very long'
            }
        })
        if (optionErrors.length > 0) {
            errors.options = optionErrors
        }
        return {
            errors,
            isValid: Object.keys(errors).length === 0
        }

    }

    render() {
        const { title, description, options, errors } = this.state
        return (
            <div>
                <MyForm
                    title={title}
                    description={description}
                    options={options}
                    errors={errors}
                    buttonValue={this.props.buttonValue || 'Create options'}

                    handleChange={this.handleChange}
                    handleOptionChange={this.handleOptionChange}
                    createOption={this.createOption}
                    deleteOption={this.deleteOption}
                    handleSubmit={this.handleSubmit}

                />
            </div>
        )
    }
}
