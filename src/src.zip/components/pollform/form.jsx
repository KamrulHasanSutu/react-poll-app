import React from 'react'
import { Form, FormGroup, Label, Input, FormFeedback, Button } from 'reactstrap'

const MyForm = ({
    title,
    description,
    options,
    errors,
    buttonValue,
    handleChange,
    handleOptionChange,
    createOption,
    deleteOption,
    handleSubmit,
}) => (

    <Form onSubmit={handleSubmit}>
{/* title * description  */}
        <FormGroup>
            <Label for='title'>Title</Label>
            <Input
                name='title'
                id='title'
                placeholder='Max Pane'
                value={title}
                onChange={handleChange}
                invalid={errors.title ? true : false}
            />
            {errors.title && <FormFeedback>{errors.title}</FormFeedback>}
        </FormGroup>
        <FormGroup>
            <Label for='description'>description</Label>
            <Input
                name='description'
                id='description'
                placeholder='...description...'
                value={description}
                onChange={handleChange}
                invalid={errors.description ? true : false}
            />
            {errors.description && <FormFeedback>{errors.description}</FormFeedback>}
        </FormGroup>

{/* add options  */}
        <FormGroup>
            <Label>Enter options
                <span style={{ color: 'white', cursor: 'pointer', borderRadius: '6px', background: 'green', marginLeft: '32px' }} onClick={createOption}>Add Options</span>

                {options.map((opt, index) => (
                    <div className='d-flex my-2' key={opt.id}>
                        <Input
                            value={opt.value}
                            onChange={ e => handleOptionChange(e, index)}
                            invalid={errors.options && errors.options[index] ? true: false}
                        />
  {/* delete */}
                        <Button
                            color='danger'
                            disabled={options.length <= 2 }
                            className='ml-2'
                            onClick={ ()=> deleteOption(index)}
                        >Delete</Button>
                    </div>
                ))}
            </Label>
        </FormGroup>
            <Button color='primary' type='submit'>
                {buttonValue}
            </Button>

    </Form>

)

export default MyForm
