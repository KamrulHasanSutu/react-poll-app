import React, { Component } from 'react'
import { Input, Button, Modal, ModalHeader, ModalBody } from 'reactstrap'
import PollList from './poll_list'
import PollForm from '../pollform'


export default class Sidebar extends Component {
    state = {
        openModal: false
    }
    toggleModal = () => {
        this.setState({
            openModal: !this.state.openModal
        })
    }
    render() {
        return (
            <div style={{ background: '#efefef', padding: '10px' }}>
                <div className="d-flex mb-5">
{/* search */}
                    <Input
                        type="text"
                        value={this.props.searchTerm}
                        placeholder="search here" onChange={e => this.props.handleSearch(e.target.value)}
                    />
                    <Button
                        className='ml-2'
                        onClick={this.toggleModal}
                    >
                        Add New
                    </Button>
{/* list of polls */}
                </div>
                <h3>List of all polls</h3>
                <PollList
                    polls={this.props.polls}
                    selectPoll={this.props.selectPoll}
                />
                <hr></hr>
{/* modal */}
                <Modal isOpen={this.state.openModal} toggle={this.toggleModal} unmountOnClose={true}>
                    <ModalHeader toggle={this.toggleModal}>
                        Create a New poll
                    </ModalHeader>
                    <ModalBody>
                        <PollForm 
                            submit={this.props.addNewPoll}
                        />
                    </ModalBody>
                </Modal>

            </div>
        )
    }
}
