import React from "react";
import { Container, Row, Col } from 'reactstrap'
import shortid from "shortid";
import MainContent from "./components/mainconent";
import Sidebar from "./components/sidebar";
import POLLS from './data/polls'

class App extends React.Component {

    state = {
        polls: [],
        selectedPoll: {},
        searchTerm: ''
    }
    componentDidMount() {
        this.setState({ polls: POLLS })
    }
    addNewPoll = poll => {
        poll.id = shortid.generate();
        poll.created = new Date();
        poll.totalVote = 0;
        poll.opinions = [];

        this.setState({
            polls: this.state.polls.concat(poll)
        })

    }
    updatePoll = upDatedPoll => {
        const polls = [...this.state.polls];
        const poll = polls.find(p => p.id === upDatedPoll.id);

        poll.title = upDatedPoll.title;
        poll.description = upDatedPoll.description;
        poll.options = upDatedPoll.options;

        this.setState({ polls })
    }
    deletePoll = pollId => {
        const polls = this.state.polls.filter(p => p.id !== pollId);
        this.setState({ polls, selectedPoll: {} })
    }
    selectPoll = pollId => {
        const poll = this.state.polls.find(p => p.id === pollId);
        this.setState({ selectedPoll: poll })
    }
    handleSearch = searchTerm => {
        this.setState({
            searchTerm
        })
    }
    perfocmSearch = () => {
        return this.state.polls.filter(poll => poll.title.toLowerCase().includes(this.state.searchTerm.toLocaleLowerCase()))
    }
    getOpinion = response => {
        const { polls } = this.state
        const poll = polls.find(p => p.id === response.pollId)
        const option = poll.options.find(o => o.id === response.selectedOption)

        poll.totalVote++;
        option.vote++;

        const opinion = {
            id: shortid.generate(),
            name: response.name,
            selectedOption: response.selectedOption
        }
        poll.opinions.push(opinion)
        this.setState({ polls })
    }

    opiShow = () => {
        if (this.state.selectedPoll.opinions) {
            const { opinions } = this.state.selectedPoll

            console.log("Indise : ", opinions);

            const element = (
                <div>
                    <h2>hi there</h2>
                </div>
            )
            const out = (
                <div>
                    <h2>{opinions[0].name}</h2>
                 
                </div>
            )
            
            return opinions ? out : element;
        }
    }


    //     <h3 className='my-5'>All Registered Users</h3>
	// 				<ul className='list-group'>
	// 					{this.state.selectedPoll.opinion(user => (
	// 						<li className='list-group-item'>
	// 							{name} 
	// 						</li>
	// 					))}
	// 				</ul>
    // }

    render() {

        const polls = this.perfocmSearch();
        console.log(this.state);

        return (
            <Container >
                <h1 style={{ textAlign: 'center' }}>Poll App</h1><hr></hr>
                {/* {console.log(this.state.selectedPoll)} */}

                <Row >
                    <Col md={4}>
                        <Sidebar
                            polls={polls}
                            selectPoll={this.selectPoll}
                            searchTerm={this.state.searchTerm}
                            handleSearch={this.handleSearch}
                            addNewPoll={this.addNewPoll}
                        />
                    </Col>
                    <Col md={8}>
                        <MainContent
                            poll={this.state.selectedPoll}
                            getOpinion={this.getOpinion}
                            updatePoll={this.updatePoll}
                            deletePoll={this.deletePoll}
                            opiShow={this.opiShow}
                        />
                    </Col>
                </Row>

                {/* <ul className='list-group'>
						{this.state.selectedPoll.opinion(user => (
							<li className='list-group-item'>
								{user.name} 
							</li>
						))}
					</ul> */}
            </Container>
        )
    }
}

export default App;